# iCode
Build IOS apps and tweaks on your jailbroken iPhone | Supports IOS 11.0 - 11.3.1

Note: This Application is in pre-alpha at the moment.

# Compatibility

iCode supports IOS 11.0 - 11.3.1 | I’m testing this on an iPhone X running IOS 11.3.1 with Electra jailbreak. More Devices coming in the future

# Credits

► Made by @SASxL3GITGLITCH